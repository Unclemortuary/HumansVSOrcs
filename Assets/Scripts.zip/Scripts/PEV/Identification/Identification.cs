
[System.Serializable]
public static class Identification {

    [System.Serializable]
    public enum Army { Humans, Orcs, Neutrals };

    [System.Serializable]
    public enum UnitType {Archer, Swordsman, Horseman,
        GeneralHouse, Barrack, Farm, Forge, Quarry, Sawmill, SimpleHouse, WatchTower};


}